const express = require('express');
const app = express();
const port = process.env.PORT || 8080;

// Secret comes from App Settings via Key Vault reference
const storageConn = process.env.STORAGE_CONN || '(not set)';

app.get('/', (_req, res) => {
  res.json({
    ok: true,
    message: 'App Service + Key Vault demo',
    storageConnMasked: storageConn.substring(0, 20) + '...'
  });
});

app.listen(port, () => console.log(`Server running on port ${port}`));
